package aquarium.models.decorations;

public class Plant extends BaseDecoration {

    public Plant() {
        super(5, 10);
    }
}
